﻿ using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;
using System.IO;
using System.Globalization;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Collections;
//--------------------------------
namespace Tools
{
    public static class utilConversion
    {

 
        //-------------------------------------------------------------------
        public static byte[] GetUint_2_bytes(UInt16 val)
        {
            byte[] ret_val = new byte[2];
            ret_val[0] = (byte)(val >> 8);
            ret_val[1] = (byte)(val & 0x00ff);
            return ret_val;
        }
        //---------------------------------------------------------------------------------------------
        public static UInt16 Get_Uint16(Byte Hi, Byte Lo)
        {
            UInt32 val = 0;
            val = Hi;
            val = val << 8;
            val |= Lo;
            return (UInt16)(val);
        }
        //---------------------------------------------------------------------------------------------
        public static UInt16[] Get_Uint16(UInt32 val)
        {
            UInt16[] data = new UInt16[2];

            data[1] = (UInt16)val;
            val = (UInt16)(val >> 16);
            data[0] = (UInt16)(val & 0x0000FFFF);
            return data;
        }
        //---------------------------------------------------------------------------------------------
        public static UInt16[] GetInt16_From_ByteArray(byte[] src)
        {
            UInt16[] bfr = new UInt16[src.Length / 2];
            int len = bfr.Length;

            int i = 0;
            int j = 0;

            do
            {
                bfr[i] = Get_Uint16(src[j], src[j + 1]);
                i++;
                j = j + 2;
            } while (i < len);

            return bfr;
        }
        //---------------------------------------------------------------------------------------------


        //public byte[] GetUInt16_From_bytes(byte val;)
        //{
        //    byte[] ret_val = new byte[2];
        //    ret_val[0] = (byte)(val >> 8);
        //    ret_val[1] = (byte)(val & 0x00ff);
        //    return ret_val;
        //}
        ////-------------------------------------------------------------------------------------------
        ////-------------------------------------------------------------------------- 
        //public UInt32 GetUInt16(byte[] bytes, int index)
        //{
        //    Array.Reverse(bytes);
        //    uint value = BitConverter.ToUInt16(bytes, index);
        //    return value;
        //}
        ////-------------------------------------------------------------------------- 
        //public UInt32 GetUInt32(byte[] bytes, int index)
        //{
        //    Array.Reverse(bytes);
        //    uint value = BitConverter.ToUInt32(bytes, index);
        //    return value;
        //}
        ////-------------------------------------------------------------------------- 
        //public byte[] GetUint_2_bytes(uint val)
        //{
        //    byte[] ret_val = new byte[2];
        //    ret_val[0] = (byte)(val >> 8);
        //    ret_val[1] = (byte)(val & 0x00ff);
        //    return ret_val;

        //    //byte[] byteArray = BitConverter.GetBytes(val);
        //    //Array.Reverse(byteArray, 0, byteArray.Length);
        //    //return byteArray;
        //}
        ////---------------------------------------------------------------------------     
        public static UInt32 Get_Uint32_From_UInt16(UInt16 Hi, UInt16 Lo)
        {
            UInt32 ret_val = 0;

            ret_val = Hi;
            ret_val = ret_val << 16;

            ret_val = ret_val | Lo;
            return ret_val;
        }
        //-----------------------------------------------------------------------------
        public static Int32 Get_Int32_From_UInt16(UInt16 Hi, UInt16 Lo)
        {
            Int32 ret_val = 0;

            ret_val = Hi;
            ret_val = ret_val << 16;

            ret_val = ret_val | Lo;
            return ret_val;
        }
       
      
        //=============================================================================
        public static String Convert_Int32_To_FormatData(UInt32 Val, int preCount, int Post_count)
        {
            String retStr = "";

            float f = (float)(Val / 100.00f);

            UInt16 t = (UInt16)f;
            String str_int_part = t.ToString();
            str_int_part = str_int_part.PadLeft(preCount, '0');

            f = f - t;
            String str_flt_part = f.ToString();
            int pos = str_flt_part.IndexOf('.');

            if (pos == -1)
            {
                str_flt_part = "00";
            }
            else
            {
                str_flt_part = str_flt_part + "000000";
            }

            str_flt_part = str_flt_part.Substring(pos + 1, Post_count);
            retStr = str_int_part + "." + str_flt_part;

            return retStr;
        }
        //===============================================================================
        public static String Convert_Int32_To_FormatData_div36000(UInt32 Val, int preCount, int Post_count)
        {
            String retStr = "";
            float f;
            try
            {
                f = (float)(Val / 36000.00f);
            }
            catch
            {
                f = 0.0f;
            }

            UInt32 t = (UInt32)f;
            String str_int_part = t.ToString();
            str_int_part = str_int_part.PadLeft(preCount, '0');

            f = f - t;
            String str_flt_part = f.ToString();
            int pos = str_flt_part.IndexOf('.');

            if (pos == -1)
            {
                str_flt_part = "00";
            }
            else
            {
                str_flt_part = str_flt_part + "000000";
                str_flt_part = str_flt_part.Substring(pos + 1, Post_count);
                retStr = str_int_part + "." + str_flt_part;
            }
            return retStr;
        }
        //===============================================================================
        public static String Convert_Int32_To_FormatData_div3600(UInt32 Val, int preCount, int Post_count)
        {
            String retStr = "";

            float f = (float)(Val / 3600.00f);

            UInt32 t = (UInt32)f;
            String str_int_part = t.ToString();
            str_int_part = str_int_part.PadLeft(preCount, '0');

            f = f - t;
            String str_flt_part = f.ToString();
            int pos = str_flt_part.IndexOf('.');

            if (pos == -1)
            {
                str_flt_part = "00";
            }
            else
            {
                str_flt_part = str_flt_part + "000000";
                str_flt_part = str_flt_part.Substring(pos + 1, Post_count);
                retStr = str_int_part + "." + str_flt_part;
            }
            return retStr;
        }
        //===============================================================================
        public static String Convert_Int32_To_FormatData_div360(UInt32 Val, int preCount, int Post_count)
        {
            String retStr = "";

            float f = (float)(Val / 360.00f);

            UInt32 t = (UInt32)f;
            String str_int_part = t.ToString();
            str_int_part = str_int_part.PadLeft(preCount, '0');

            f = f - t;
            String str_flt_part = f.ToString();
            int pos = str_flt_part.IndexOf('.');

            if (pos == -1)
            {
                str_flt_part = "00";
            }
            else
            {
                str_flt_part = str_flt_part + "000000";
                str_flt_part = str_flt_part.Substring(pos + 1, Post_count);
                retStr = str_int_part + "." + str_flt_part;
            }
            return retStr;
        }
       
       
        //--------------------------------------------------------------------------------------------------
        
        //-------------------------------------------------------------------------------------------------------
        public static String Get_Random_Uint16_as_String()
        {
            String retStr;

            Random rnd = new Random();
            UInt16 n = (UInt16)(rnd.Next(1, 0xffff));
            retStr = n.ToString();
            retStr = retStr.PadLeft(5, '0');
            return retStr;
        }
        //----------------------------------------------------------------------------------------------------------
        public static String Get_Random_Uint16_as_HEX_String()
        {
            String retStr;

            Random rnd = new Random();
            UInt16 n = (UInt16)(rnd.Next(1, 0xffff));
            retStr = n.ToString("X");
            return retStr;
        }
        //----------------------------------------------------------------------------------------------------------
        public static String Get_Random_2digit_fraction_string()
        {
            Random rnd = new Random();
            byte k = (byte)(rnd.Next(10, 99));
            String s = "." + k.ToString();
            return s;
        }
         
        //------------------------------------------------------------------------------------------------
        public static String Get_Key_Code_String_Val(int ch)
        {
            String retStr = "";

            if ((ch >= 96) && (ch < 104))
            {
                ch = ch - 96;
            }
            retStr = ch.ToString();
            return retStr;
        }
        //------------------------------------------------------------------------------------------------
       
       
        //===============================================================================================
        public static Color Get_colour(String val, String hi, String lo)
        {
            Color ret_colour;

            decimal param_val = Convert.ToDecimal(val);
            decimal high_val = Convert.ToDecimal(hi);
            decimal lo_val = Convert.ToDecimal(lo);

            if (param_val >= high_val)
            {
                ret_colour = Color.Red;
            }
            else if (param_val <= lo_val)
            {
                ret_colour = Color.Yellow;
            }
            else
            {
                ret_colour = Color.LightGreen;
            }
            return ret_colour;
        }
        //_________________________________________________________________________________________________________
        public static decimal Get_decimal_from_string(String val)
        {
            decimal d = 0;
            try
            {
                d = decimal.Parse(val, CultureInfo.InvariantCulture);
               
            }catch(Exception ex)
            {
                string s = ex.ToString();
            }

            return d;
        }
        //__________________________________________________________________________________________________________
     
       
        //__________________________________________________________________________________________
        public static int Get_first_Not_Null_index_From_Str_Buffer(String[] bfr)
        {
            int i = 0;

            for (i = 0; i < bfr.Length; i++)
            {
                try
                {
                    if (bfr[i] != null)
                    {
                        return i;
                    }
                }
                catch
                {

                }
            }
            return -1;
        }
        //________________________________________________________________________________________________________
         public static int Get_Not_Null_Count_From_Str_Buffer(String[] bfr)
        {
            int count = 0;

            for (int i = 0; i < bfr.Length; i++)
            {
                try
                {
                    if (bfr[i] != null)
                    {
                        count++;
                    }
                }
                catch
                {

                }
            }
            return count;
        }
      
        //____________________________________________________________________________________________________________________
      
        public static UInt16[] Convert_str32_To_Uint16_Hi_Lo(String val)
        {
            UInt16[] ret_val = new UInt16[2];

            UInt32 tot = Convert.ToUInt32(val);

            ret_val[1] = (UInt16)tot;
            tot = tot >> 16;
            tot = tot & 0x0000ffff;
            ret_val[0] = (UInt16)(tot);

            return ret_val;
        }
       
        //_________________________________________________________________________________________________________________
        public static byte[] Get_Bytes_from_string(string msg)
        {
            byte[] b;
            b = new byte[msg.Length];                            
            b = Encoding.Default.GetBytes(msg);  
            return b;
        }
        //_________________________________________________________________________________________________________________
        public static int purse_array_value_from_str(string find_str, string packet, int start_index, ref List<string> dest_bfr)
        {
            string temp_str = "";
            int var_start_idx = 0;
            int bracket_st = 0;
            int bracket_end = 0;
     
            var_start_idx = packet.IndexOf(find_str, start_index);
            bracket_st = packet.IndexOf('[', var_start_idx);
            bracket_end = packet.IndexOf(']', bracket_st);

            temp_str = packet.Substring(bracket_st + 1, bracket_end - bracket_st - 1);

            var charsToRemove = new string[] { "@", "'", "\n", " " };
            foreach (var c in charsToRemove)
            {
                temp_str = temp_str.Replace(c, string.Empty);
            }
            string[] val = temp_str.Split(',');


            for (int i=0;i<val.Length;i++)
            {
                dest_bfr.Add(val[i]);
            }
            return bracket_end;
        }
        //_________________________________________________________________________________________________________________
       
        //_________________________________________________________________________________________________________________
        public static void convert_value(ref List<string> bfr, float src_min, float src_max, int  dst_min,int dst_max) 
        {
            if (src_min < 0)
            {
                float src_diff = src_max - src_min;
                float dst_diff = dst_max - dst_min;
                float unit = dst_diff / src_diff;

                float zero = dst_max + ((dst_min - dst_max) / 2);

                for (int i = 0; i < bfr.Count; i++)
                {
                    decimal d = Convert.ToDecimal(bfr[i]);
                    d *= (decimal)unit;
                    d += (decimal)zero;
                    bfr[i] = d.ToString();
                }
            }
            else
            {
                float src_diff = src_max - src_min;
                float dst_diff = dst_max - dst_min;
                float unit = dst_diff / src_diff;

                for (int i = 0; i < bfr.Count; i++)
                {
                    decimal d = Convert.ToDecimal(bfr[i]);
                    d *= (decimal)unit;
                    d += (decimal)dst_min;
                    bfr[i] = d.ToString();
                }
            }
        }
        //_________________________________________________________________________________________________________________
        public static Point[] convert_str_list_to_point(List<string> bfr_X, List<string> bfr_Y)
        {
            Point[] pt = new Point[bfr_X.Count];
            for(int i=0;i<bfr_X.Count;i++)
            {
                string str_x = bfr_X[i].Replace(',', '.');
                string str_y = bfr_Y[i].Replace(',', '.');
                decimal x = Convert.ToDecimal(str_x);
                decimal y = Convert.ToDecimal(str_y);
                pt[i] = new Point((int)x,(int)y);
            }
            return pt;
        }
        //__________________________________________________________________________________________________________________
        public static decimal convert_Exp_value(string val)
        {
            decimal dec = decimal.Parse(val, System.Globalization.NumberStyles.Any);
            return dec;
        }
        //__________________________________________________________________________________________________________________
        public static string convert_Exp_value(string val, decimal compare_val, int decimal_place)
        {
            string result = "";
            decimal dec = decimal.Parse(val, System.Globalization.NumberStyles.Any);
            string str_val = dec.ToString();
            if (dec < compare_val)
            {
                if (decimal_place == 1) result = "0.0";
                else if (decimal_place == 2) result = "0.00";
                else if (decimal_place == 3) result = "0.000";
                else result = "0.0";
            }
            else
            {
                int k = str_val.IndexOf('.');
                string s = str_val.Substring(k + 1);
                result=utility.allign_str(s, decimal_place);
            }

            return result;   
        }
        //__________________________________________________________________________________________________________________
        public static int get_str_upto_non_digit(string find_str, string packet, int index, ref string str_result)
        {
            int str_idx = packet.IndexOf(find_str, index);
            if (str_idx == -1) return index;

            str_idx += find_str.Length;

            int running_index = str_idx;

            for (int i = index; i < packet.Length; i++)
            {
                string s = packet.Substring(running_index, 1);
                if ((s != "0") && (s != "1") && (s != "2") && (s != "3") && (s != "4") &&
                   (s != "5") && (s != "6") && (s != "7") && (s != "8") && (s != "9"))
                {
                   str_result = packet.Substring(str_idx, running_index - str_idx);
                    return str_idx;
                }
                else
                {
                    running_index++;
                }
            }
            return str_idx;
        }
        //_____________________________________________________________________________________________________________________________
         public static bool parameter_Not_Within_Range(string max_val,string min_val, string running_val)
        {
            try
            {
                decimal max = Convert.ToDecimal(max_val);
                decimal min = Convert.ToDecimal(min_val);
                decimal running = Convert.ToDecimal(running_val);

                if ((running > max) || (running < min))
                {
                   // MessageBox.Show("")
                    return true;
                }
                else
                {
                    return false;
                }
            }catch(Exception ex)
            {

            }
            return true;
        }
        
        //_____________________________________________________________________________________________________________________
         public static double[] String_2_Values(string strvalues)
        {
            double[] dvalues = null;
            try
            {
                dvalues = Array.ConvertAll(strvalues.Split(','), Double.Parse);
            }
            catch (System.FormatException ex)
            {
                
            }
            return dvalues;
        }
        //______________________________________________________________________________________________________
        public static double ConvertToRadians(double angle)
        {
            return (Math.PI / 180) * angle;
        }
        //__________________________________________________________________________________________________________________
        public static Point Convert_deg_to_point(Point cp, double radious, double deg)
        {
            double x_var = radious * Math.Cos(ConvertToRadians(deg));
            double y_var = radious * Math.Sin(ConvertToRadians(deg));
           
            Point p = new Point();
            p.X = cp.X + (int)x_var; 
            p.Y = cp.Y - (int)y_var;

            return p;
        }
        
        //________________________________________________________________________________________________________
       public static Color color_from_RBG_string(string str_rgb)
        {
            Color c;

            try
            {
                var v = str_rgb.Split(',');
                int r = Convert.ToInt16(v[0]);
                int g = Convert.ToInt16(v[1]);
                int b = Convert.ToInt16(v[2]);

                c = Color.FromArgb(r, g, b);
            }
            catch(Exception ex)
            {
                string s = ex.ToString();
                c = Color.Black;
            }

            return c;

        }
        //____________________________________________________________________________________________________
        public static string Get_Binary_8bit(string value)
        {
            byte b = Convert.ToByte(value);
            string s = Convert.ToString(b, 2);
            s = s.PadLeft(8, '0');
            return s;
        }
        //____________________________________________________________________________________________________
        public static int Get_Int_from_Binary(string value)
        {
            Int16 val = Convert.ToInt16(value, 2);
            return val;
        }
        //____________________________________________________________________________________________________
        public static string Get_string_from_Binary(string value)
        {
            Int16 val = Convert.ToInt16(value, 2);
            return val.ToString();
        }
	//___________________________________________________________________________________________________________
        public static string Get_Hex_8bit(string value)
        {
            byte b = Convert.ToByte(value);
            string s = Convert.ToString(b, 16);
            s = s.PadLeft(2, '0');
            s = s.ToUpper();
            s = "0x" + s;
            return s;
        }
        //____________________________________________________________________________________________________
        public static bool Notbin(string s)
        {
            foreach (var c in s)
                if (c != '0' && c != '1')
                    return true;
            return false;
        }

        public static string Convert_str_bytes_from_Uint16(UInt16 val)
        {
            byte[] b = new byte[2];           
            byte LSB = (byte)val;
            val =(UInt16) (val >> 8);
            byte MSB = (byte)val;

            string str_MSB = MSB.ToString();
            str_MSB = str_MSB.PadLeft(2, '0');

            string str_LSB = LSB.ToString();
            str_LSB = str_LSB.PadLeft(2, '0');

            string s = str_MSB + " " + str_LSB;
            return s;
        }

        public static string Convert_str_ASCII_from_Uint16(UInt16 val)
        {
            byte[] b = new byte[2];
            char LSB = (char)val;
            val = (UInt16)(val >> 8);
            char MSB = (char)val;
            string s = MSB.ToString() + " " + LSB.ToString();
            return s;
        }

        public static byte[] Get_Bytes_From_Uint16(UInt16[] bfr)
        {
            int index = 0;
            byte[] b = new byte[bfr.Length * sizeof(UInt16)];

            foreach (UInt16 i in bfr)
            {
                byte[] bytes = BitConverter.GetBytes(i);
                if (BitConverter.IsLittleEndian) Array.Reverse(bytes);
                b[index] = bytes[0]; index++;
                b[index] = bytes[1]; index++;
            }
            return b;
        }

        public static bool value_Not_In_Tolerance(float v1, float v2, double tolerance)
        {
            if (Math.Abs(v1 - v2) < tolerance)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
       




    }
}