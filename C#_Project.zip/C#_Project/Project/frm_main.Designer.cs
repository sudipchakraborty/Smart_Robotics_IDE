﻿namespace Project
{
    partial class frm_main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chk_real_robot = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbo_rbt_select = new System.Windows.Forms.ComboBox();
            this.pb_comm_status = new System.Windows.Forms.PictureBox();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.btn_connect = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_baud_rate = new System.Windows.Forms.TextBox();
            this.txt_port = new System.Windows.Forms.TextBox();
            this.Timer_Movement = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_insert = new System.Windows.Forms.Button();
            this.cbo_command = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dg_param_display = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_get_parameter = new System.Windows.Forms.Button();
            this.dg_program = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_save_As = new System.Windows.Forms.Button();
            this.btn_load = new System.Windows.Forms.Button();
            this.btn_prg_pause = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_dn = new System.Windows.Forms.Button();
            this.btn_up = new System.Windows.Forms.Button();
            this.btn_line_insert = new System.Windows.Forms.Button();
            this.btn_program_line_delete = new System.Windows.Forms.Button();
            this.btn_send = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_scan_row = new System.Windows.Forms.TextBox();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_run = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_clear_history = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.timer_program = new System.Windows.Forms.Timer(this.components);
            this.btn_alarm_clear = new System.Windows.Forms.Button();
            this.chk_simulated_robot = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_comm_status)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_param_display)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_program)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lst_msg
            // 
            this.lst_msg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lst_msg.ForeColor = System.Drawing.Color.White;
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.ItemHeight = 32;
            this.lst_msg.Location = new System.Drawing.Point(9, 47);
            this.lst_msg.Margin = new System.Windows.Forms.Padding(6);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(446, 1252);
            this.lst_msg.TabIndex = 0;
            this.lst_msg.SelectedIndexChanged += new System.EventHandler(this.lst_msg_SelectedIndexChanged);
            this.lst_msg.DoubleClick += new System.EventHandler(this.lst_msg_DoubleClick);
            this.lst_msg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lst_msg_KeyDown);
            this.lst_msg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lst_msg_MouseDown);
            // 
            // txt_msg
            // 
            this.txt_msg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_msg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_msg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_msg.ForeColor = System.Drawing.Color.White;
            this.txt_msg.Location = new System.Drawing.Point(17, 1438);
            this.txt_msg.Margin = new System.Windows.Forms.Padding(6);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(1307, 43);
            this.txt_msg.TabIndex = 1;
            this.txt_msg.Text = "messagebox";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chk_simulated_robot);
            this.groupBox1.Controls.Add(this.chk_real_robot);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cbo_rbt_select);
            this.groupBox1.Controls.Add(this.pb_comm_status);
            this.groupBox1.Controls.Add(this.btn_disconnect);
            this.groupBox1.Controls.Add(this.btn_connect);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_baud_rate);
            this.groupBox1.Controls.Add(this.txt_port);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(22, 73);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(563, 470);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Communication";
            // 
            // chk_real_robot
            // 
            this.chk_real_robot.AutoSize = true;
            this.chk_real_robot.Location = new System.Drawing.Point(39, 401);
            this.chk_real_robot.Name = "chk_real_robot";
            this.chk_real_robot.Size = new System.Drawing.Size(160, 36);
            this.chk_real_robot.TabIndex = 6;
            this.chk_real_robot.Text = "Real Robot";
            this.chk_real_robot.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 53);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "ROBOT";
            // 
            // cbo_rbt_select
            // 
            this.cbo_rbt_select.FormattingEnabled = true;
            this.cbo_rbt_select.Items.AddRange(new object[] {
            "Dobot_Magician",
            "UARM_Metal",
            "DEMO",
            "Ender_3D_Printer"});
            this.cbo_rbt_select.Location = new System.Drawing.Point(15, 87);
            this.cbo_rbt_select.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.cbo_rbt_select.Name = "cbo_rbt_select";
            this.cbo_rbt_select.Size = new System.Drawing.Size(508, 40);
            this.cbo_rbt_select.TabIndex = 4;
            this.cbo_rbt_select.SelectedIndexChanged += new System.EventHandler(this.cbo_rbt_select_SelectedIndexChanged);
            // 
            // pb_comm_status
            // 
            this.pb_comm_status.BackColor = System.Drawing.Color.Transparent;
            this.pb_comm_status.Location = new System.Drawing.Point(409, 209);
            this.pb_comm_status.Margin = new System.Windows.Forms.Padding(6);
            this.pb_comm_status.Name = "pb_comm_status";
            this.pb_comm_status.Size = new System.Drawing.Size(61, 62);
            this.pb_comm_status.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_comm_status.TabIndex = 3;
            this.pb_comm_status.TabStop = false;
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.ForeColor = System.Drawing.Color.Black;
            this.btn_disconnect.Location = new System.Drawing.Point(279, 298);
            this.btn_disconnect.Margin = new System.Windows.Forms.Padding(6);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(261, 72);
            this.btn_disconnect.TabIndex = 2;
            this.btn_disconnect.Text = "Disconnect";
            this.btn_disconnect.UseVisualStyleBackColor = true;
            this.btn_disconnect.Click += new System.EventHandler(this.btn_disconnect_Click);
            // 
            // btn_connect
            // 
            this.btn_connect.ForeColor = System.Drawing.Color.Black;
            this.btn_connect.Location = new System.Drawing.Point(24, 298);
            this.btn_connect.Margin = new System.Windows.Forms.Padding(6);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(243, 72);
            this.btn_connect.TabIndex = 2;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(362, 169);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Comm. Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 183);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "Baud Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 241);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "PORT";
            // 
            // txt_baud_rate
            // 
            this.txt_baud_rate.BackColor = System.Drawing.Color.Gray;
            this.txt_baud_rate.Location = new System.Drawing.Point(162, 180);
            this.txt_baud_rate.Margin = new System.Windows.Forms.Padding(6);
            this.txt_baud_rate.Name = "txt_baud_rate";
            this.txt_baud_rate.ReadOnly = true;
            this.txt_baud_rate.Size = new System.Drawing.Size(126, 39);
            this.txt_baud_rate.TabIndex = 0;
            this.txt_baud_rate.Text = "115200";
            this.txt_baud_rate.TextChanged += new System.EventHandler(this.txt_baud_rate_TextChanged);
            // 
            // txt_port
            // 
            this.txt_port.Location = new System.Drawing.Point(162, 234);
            this.txt_port.Margin = new System.Windows.Forms.Padding(6);
            this.txt_port.Name = "txt_port";
            this.txt_port.Size = new System.Drawing.Size(126, 39);
            this.txt_port.TabIndex = 0;
            this.txt_port.Text = "COM18";
            this.txt_port.TextChanged += new System.EventHandler(this.txt_port_TextChanged);
            // 
            // Timer_Movement
            // 
            this.Timer_Movement.Tick += new System.EventHandler(this.Timer_Movement_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_insert);
            this.groupBox3.Controls.Add(this.cbo_command);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(594, 1267);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox3.Size = new System.Drawing.Size(728, 162);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Command Terminal";
            // 
            // btn_insert
            // 
            this.btn_insert.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btn_insert.Location = new System.Drawing.Point(627, 35);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(6);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(89, 90);
            this.btn_insert.TabIndex = 9;
            this.btn_insert.Text = ">>";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // cbo_command
            // 
            this.cbo_command.FormattingEnabled = true;
            this.cbo_command.Location = new System.Drawing.Point(11, 47);
            this.cbo_command.Margin = new System.Windows.Forms.Padding(6);
            this.cbo_command.Name = "cbo_command";
            this.cbo_command.Size = new System.Drawing.Size(600, 40);
            this.cbo_command.Sorted = true;
            this.cbo_command.TabIndex = 8;
            this.cbo_command.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbo_command_KeyDown);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dg_param_display);
            this.groupBox4.Location = new System.Drawing.Point(24, 555);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox4.Size = new System.Drawing.Size(561, 755);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parameter Display";
            // 
            // dg_param_display
            // 
            this.dg_param_display.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_param_display.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dg_param_display.Location = new System.Drawing.Point(13, 43);
            this.dg_param_display.Margin = new System.Windows.Forms.Padding(6);
            this.dg_param_display.Name = "dg_param_display";
            this.dg_param_display.RowHeadersWidth = 51;
            this.dg_param_display.RowTemplate.Height = 25;
            this.dg_param_display.Size = new System.Drawing.Size(536, 700);
            this.dg_param_display.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Parameter";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Value";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // btn_get_parameter
            // 
            this.btn_get_parameter.Location = new System.Drawing.Point(17, 1322);
            this.btn_get_parameter.Margin = new System.Windows.Forms.Padding(6);
            this.btn_get_parameter.Name = "btn_get_parameter";
            this.btn_get_parameter.Size = new System.Drawing.Size(251, 104);
            this.btn_get_parameter.TabIndex = 9;
            this.btn_get_parameter.Text = "GET Parameter";
            this.btn_get_parameter.UseVisualStyleBackColor = true;
            this.btn_get_parameter.Click += new System.EventHandler(this.btn_get_parameter_Click);
            // 
            // dg_program
            // 
            this.dg_program.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_program.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg_program.DefaultCellStyle = dataGridViewCellStyle2;
            this.dg_program.Location = new System.Drawing.Point(9, 47);
            this.dg_program.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.dg_program.Name = "dg_program";
            this.dg_program.RowHeadersWidth = 51;
            this.dg_program.RowTemplate.Height = 29;
            this.dg_program.Size = new System.Drawing.Size(583, 891);
            this.dg_program.TabIndex = 10;
            this.dg_program.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dg_program_KeyDown);
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Command";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 300;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.btn_prg_pause);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.btn_send);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txt_scan_row);
            this.groupBox2.Controls.Add(this.btn_stop);
            this.groupBox2.Controls.Add(this.btn_run);
            this.groupBox2.Controls.Add(this.dg_program);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(594, 73);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox2.Size = new System.Drawing.Size(750, 1184);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Program";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_save);
            this.groupBox7.Controls.Add(this.btn_save_As);
            this.groupBox7.Controls.Add(this.btn_load);
            this.groupBox7.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox7.Location = new System.Drawing.Point(9, 948);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(419, 226);
            this.groupBox7.TabIndex = 22;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Program File Tools";
            // 
            // btn_save
            // 
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(150, 51);
            this.btn_save.Margin = new System.Windows.Forms.Padding(6);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(260, 154);
            this.btn_save.TabIndex = 20;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_save_As
            // 
            this.btn_save_As.ForeColor = System.Drawing.Color.Black;
            this.btn_save_As.Location = new System.Drawing.Point(17, 129);
            this.btn_save_As.Margin = new System.Windows.Forms.Padding(6);
            this.btn_save_As.Name = "btn_save_As";
            this.btn_save_As.Size = new System.Drawing.Size(121, 76);
            this.btn_save_As.TabIndex = 21;
            this.btn_save_As.Text = "Save As";
            this.btn_save_As.UseVisualStyleBackColor = true;
            this.btn_save_As.Click += new System.EventHandler(this.btn_save_As_Click);
            // 
            // btn_load
            // 
            this.btn_load.ForeColor = System.Drawing.Color.Black;
            this.btn_load.Location = new System.Drawing.Point(17, 51);
            this.btn_load.Margin = new System.Windows.Forms.Padding(6);
            this.btn_load.Name = "btn_load";
            this.btn_load.Size = new System.Drawing.Size(121, 68);
            this.btn_load.TabIndex = 21;
            this.btn_load.Text = "Load";
            this.btn_load.UseVisualStyleBackColor = true;
            this.btn_load.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // btn_prg_pause
            // 
            this.btn_prg_pause.ForeColor = System.Drawing.Color.Maroon;
            this.btn_prg_pause.Location = new System.Drawing.Point(606, 493);
            this.btn_prg_pause.Name = "btn_prg_pause";
            this.btn_prg_pause.Size = new System.Drawing.Size(114, 147);
            this.btn_prg_pause.TabIndex = 20;
            this.btn_prg_pause.Text = "PAUSE";
            this.btn_prg_pause.UseVisualStyleBackColor = true;
            this.btn_prg_pause.Click += new System.EventHandler(this.btn_prg_pause_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_dn);
            this.groupBox6.Controls.Add(this.btn_up);
            this.groupBox6.Controls.Add(this.btn_line_insert);
            this.groupBox6.Controls.Add(this.btn_program_line_delete);
            this.groupBox6.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox6.Location = new System.Drawing.Point(437, 948);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox6.Size = new System.Drawing.Size(313, 226);
            this.groupBox6.TabIndex = 19;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Program Edit Tools";
            // 
            // btn_dn
            // 
            this.btn_dn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_dn.Location = new System.Drawing.Point(12, 115);
            this.btn_dn.Margin = new System.Windows.Forms.Padding(6);
            this.btn_dn.Name = "btn_dn";
            this.btn_dn.Size = new System.Drawing.Size(123, 90);
            this.btn_dn.TabIndex = 18;
            this.btn_dn.Text = "DN";
            this.btn_dn.UseVisualStyleBackColor = true;
            this.btn_dn.Click += new System.EventHandler(this.btn_dn_Click_1);
            // 
            // btn_up
            // 
            this.btn_up.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_up.Location = new System.Drawing.Point(12, 44);
            this.btn_up.Margin = new System.Windows.Forms.Padding(6);
            this.btn_up.Name = "btn_up";
            this.btn_up.Size = new System.Drawing.Size(123, 68);
            this.btn_up.TabIndex = 19;
            this.btn_up.Text = "UP";
            this.btn_up.UseVisualStyleBackColor = true;
            this.btn_up.Click += new System.EventHandler(this.btn_up_Click_1);
            // 
            // btn_line_insert
            // 
            this.btn_line_insert.ForeColor = System.Drawing.Color.Green;
            this.btn_line_insert.Location = new System.Drawing.Point(147, 44);
            this.btn_line_insert.Margin = new System.Windows.Forms.Padding(6);
            this.btn_line_insert.Name = "btn_line_insert";
            this.btn_line_insert.Size = new System.Drawing.Size(134, 68);
            this.btn_line_insert.TabIndex = 17;
            this.btn_line_insert.Text = "Insert";
            this.btn_line_insert.UseVisualStyleBackColor = true;
            this.btn_line_insert.Click += new System.EventHandler(this.btn_line_insert_Click_1);
            // 
            // btn_program_line_delete
            // 
            this.btn_program_line_delete.ForeColor = System.Drawing.Color.Maroon;
            this.btn_program_line_delete.Location = new System.Drawing.Point(147, 115);
            this.btn_program_line_delete.Margin = new System.Windows.Forms.Padding(6);
            this.btn_program_line_delete.Name = "btn_program_line_delete";
            this.btn_program_line_delete.Size = new System.Drawing.Size(134, 90);
            this.btn_program_line_delete.TabIndex = 16;
            this.btn_program_line_delete.Text = "Delete";
            this.btn_program_line_delete.UseVisualStyleBackColor = true;
            this.btn_program_line_delete.Click += new System.EventHandler(this.btn_program_line_delete_Click);
            // 
            // btn_send
            // 
            this.btn_send.ForeColor = System.Drawing.Color.Maroon;
            this.btn_send.Location = new System.Drawing.Point(609, 46);
            this.btn_send.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(111, 195);
            this.btn_send.TabIndex = 17;
            this.btn_send.Text = "SEND";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(604, 830);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 32);
            this.label5.TabIndex = 16;
            this.label5.Text = "Scan Row";
            // 
            // txt_scan_row
            // 
            this.txt_scan_row.Location = new System.Drawing.Point(611, 887);
            this.txt_scan_row.Margin = new System.Windows.Forms.Padding(6);
            this.txt_scan_row.Name = "txt_scan_row";
            this.txt_scan_row.Size = new System.Drawing.Size(76, 39);
            this.txt_scan_row.TabIndex = 13;
            this.txt_scan_row.Text = "0";
            // 
            // btn_stop
            // 
            this.btn_stop.ForeColor = System.Drawing.Color.Teal;
            this.btn_stop.Location = new System.Drawing.Point(605, 647);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(113, 156);
            this.btn_stop.TabIndex = 11;
            this.btn_stop.Text = "STOP";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // btn_run
            // 
            this.btn_run.ForeColor = System.Drawing.Color.Teal;
            this.btn_run.Location = new System.Drawing.Point(609, 249);
            this.btn_run.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btn_run.Name = "btn_run";
            this.btn_run.Size = new System.Drawing.Size(109, 237);
            this.btn_run.TabIndex = 11;
            this.btn_run.Text = "RUN";
            this.btn_run.UseVisualStyleBackColor = true;
            this.btn_run.Click += new System.EventHandler(this.btn_run_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_clear_history);
            this.groupBox5.Controls.Add(this.lst_msg);
            this.groupBox5.ForeColor = System.Drawing.Color.White;
            this.groupBox5.Location = new System.Drawing.Point(1356, 73);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.groupBox5.Size = new System.Drawing.Size(468, 1412);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "History";
            // 
            // btn_clear_history
            // 
            this.btn_clear_history.ForeColor = System.Drawing.Color.Black;
            this.btn_clear_history.Location = new System.Drawing.Point(28, 1323);
            this.btn_clear_history.Margin = new System.Windows.Forms.Padding(6);
            this.btn_clear_history.Name = "btn_clear_history";
            this.btn_clear_history.Size = new System.Drawing.Size(429, 79);
            this.btn_clear_history.TabIndex = 1;
            this.btn_clear_history.Text = "CLEAR HISTORY";
            this.btn_clear_history.UseVisualStyleBackColor = true;
            this.btn_clear_history.Click += new System.EventHandler(this.btn_clear_history_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(654, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(627, 45);
            this.label4.TabIndex = 13;
            this.label4.Text = "Smart IDE for Robotics Reserach";
            // 
            // timer_program
            // 
            this.timer_program.Interval = 1;
            this.timer_program.Tick += new System.EventHandler(this.timer_program_Tick);
            // 
            // btn_alarm_clear
            // 
            this.btn_alarm_clear.Location = new System.Drawing.Point(280, 1325);
            this.btn_alarm_clear.Margin = new System.Windows.Forms.Padding(6);
            this.btn_alarm_clear.Name = "btn_alarm_clear";
            this.btn_alarm_clear.Size = new System.Drawing.Size(282, 104);
            this.btn_alarm_clear.TabIndex = 14;
            this.btn_alarm_clear.Text = "ALARM CLEAR";
            this.btn_alarm_clear.UseVisualStyleBackColor = true;
            this.btn_alarm_clear.Click += new System.EventHandler(this.btn_alarm_clear_Click);
            // 
            // chk_simulated_robot
            // 
            this.chk_simulated_robot.AutoSize = true;
            this.chk_simulated_robot.Location = new System.Drawing.Point(223, 401);
            this.chk_simulated_robot.Name = "chk_simulated_robot";
            this.chk_simulated_robot.Size = new System.Drawing.Size(223, 36);
            this.chk_simulated_robot.TabIndex = 6;
            this.chk_simulated_robot.Text = "Simulated Robot";
            this.chk_simulated_robot.UseVisualStyleBackColor = true;
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1848, 1560);
            this.Controls.Add(this.btn_alarm_clear);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_get_parameter);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt_msg);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frm_main";
            this.Text = "C# Template Project";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_main_FormClosing);
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_comm_status)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_param_display)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_program)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox lst_msg;
        private TextBox txt_msg;
        private GroupBox groupBox1;
        private Button btn_disconnect;
        private Button btn_connect;
        private Label label2;
        private Label label1;
        private TextBox txt_baud_rate;
        private TextBox txt_port;
        private PictureBox pb_comm_status;
        private Label label3;
        private System.Windows.Forms.Timer Timer_Movement;
        private GroupBox groupBox3;
        private ComboBox cbo_command;
        private GroupBox groupBox4;
        private DataGridView dg_param_display;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private Button btn_get_parameter;
        private DataGridView dg_program;
        private GroupBox groupBox2;
        private Button btn_stop;
        private Button btn_run;
        private GroupBox groupBox5;
        private Label label4;
        private Button btn_insert;
        private DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Timer timer_program;
        private TextBox txt_scan_row;
        private Label label5;
        private Button btn_send;
        private GroupBox groupBox6;
        private Button btn_dn;
        private Button btn_up;
        private Button btn_line_insert;
        private Button btn_program_line_delete;
        private Button btn_save;
        private Button btn_alarm_clear;
        private Button btn_clear_history;
        private Button btn_save_As;
        private Button btn_load;
        private ComboBox cbo_rbt_select;
        private Label label6;
        private Button btn_prg_pause;
        private GroupBox groupBox7;
        private CheckBox chk_real_robot;
        private CheckBox chk_simulated_robot;
    }
}