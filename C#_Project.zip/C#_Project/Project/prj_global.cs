﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    public static class prj_global
    {
        public static string Port;
        public static string Baud_Rate;
        public static string File_Path;
        public static string Selected_Robot;


        public  enum robot_type
        {
            Dobot_Magician,
            UARM_Metal,
            DEMO,
            Ender_3D_Printer,
            Niryo_One
        };




















    }
}
