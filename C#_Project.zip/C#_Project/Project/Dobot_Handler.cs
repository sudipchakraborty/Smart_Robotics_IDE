﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Tools;

namespace Project
{
    public  class Dobot_Handler
    {
        public bool exit=false;
        Thread th;
        public string command="";

        private byte isJoint = (byte)0;
        public bool isConnectted = false;
        private JogCmd currentCmd;
        private Pose pose = new Pose();
        private System.Timers.Timer posTimer = new System.Timers.Timer();

        int temp_var=0;
        public string response = "";

        Pose p = new Pose();
       
        public Dobot_Handler()
        {
            th = new Thread(command_process);
            th.Start();
        }
        public void Get_Filled(ref ComboBox cb)
        {
            cb.Items.Add("cp 1 200 10 100 100");
            cb.Items.Add("get_serial");
            cb.Items.Add("MOV Y");
            cb.Items.Add("MOV Z=");

            cb.Items.Add("param");
            cb.Items.Add("set_serial 0123456789");
            cb.Items.Add("VELOCITY=");
            cb.Items.Add("X=");
            cb.Items.Add("Y=");
        }
        

















        public void command_process()
        {
            while (!exit)
            {
                if ((command.Length>0))
                {
                    string[] lst = command.Split(" ");

                    switch (lst[0])
                    {
                        case "param":
                            DobotDll.GetPose(ref p);
                            response = "Param Read OK";
                            break;
                        ////////////////
                        case "cp":
                            byte mode = Convert.ToByte(lst[1]);
                            float x = (float)Convert.ToDecimal(lst[2]);
                            float y = (float)Convert.ToDecimal(lst[3]);
                            float z = (float)Convert.ToDecimal(lst[4]);
                            float velocity = (float)Convert.ToDecimal(lst[5]);
                            cp(mode, x, y, z, velocity);

                            Pose pose = new Pose();
                            pose.x= x;
                            pose.y= y;
                            pose.z= z;

                            int time_count = 50;
                            while(!(reach_target(pose)))
                            {
                                Thread.Sleep(100);
                                time_count--;
                                if (time_count <= 0)
                                {
                                    response = "Error!!!Robot does reach target";
                                    return;                                 
                                }                               
                            }
                            response = "CP Send OK";
                            break;
                        ///////////////
                        case "sleep":
                            int d = Convert.ToInt16(lst[1]);
                            Thread.Sleep(d);                              
                            break;
                        ////////////////
                        case "set_serial":
                       int k= DobotDll.SetDeviceSN(lst[1]);
                            if (k == 0) response = "Serial Send OK";
                            break;
                        ////////////////
                        case "get_serial":
                            StringBuilder sn = new StringBuilder();
                            DobotDll.GetDeviceSN(sn, 100);
                            response=sn.ToString();
                            break;
                        ////////////////
                        case "reset_pose":
                            bool b;
                            if (lst[1] == "0") b = false; else b = true;
                            float rear_angle =(float) Convert.ToDouble(lst[2]);
                            float front_angle = (float)Convert.ToDouble(lst[3]);
                            k = DobotDll.ResetPose(b,rear_angle,front_angle);
                            if (k == 0) response = "Pose Reset OK";
                            break;
                        ////////////////
                        case "clr_alarm":                           
                            k = DobotDll.ClearAllAlarmsState();
                            if (k == 0) response = "Cleared All Alarm";
                            break;
                        //////////////////
                        case "set_home":
                            HOMEParams hp = new HOMEParams();
                            x = (float)Convert.ToDecimal(lst[1]);
                            y = (float)Convert.ToDecimal(lst[2]);
                            z = (float)Convert.ToDecimal(lst[3]);
                            float  r = (float)Convert.ToDecimal(lst[4]);

                            hp.x = x; hp.y=y; hp.z=z;hp.r=r;
                            ulong ci = 0;
                            k = DobotDll.SetHOMEParams(ref hp,false,ref ci);
                            if (k == 0) response = "Home Position Set OK";
                            break;
                        ////////////////////
                        case "get_home":
                             hp = new HOMEParams();
                           
                            k = DobotDll.GetHOMEParams(ref hp);

                            string h_x = hp.x.ToString();
                            string h_y = hp.x.ToString();
                            string h_z = hp.x.ToString();
                            string h_r = hp.x.ToString();

                            if (k == 0) response = "Home Param=" + h_x + "," + h_y + "," + h_z + "," + h_r;
                            break;
                        ////////////////////
                        case "go_home":
                            HOMECmd hcmd = new HOMECmd();
                            UInt64 idx = 0;
                            k = DobotDll.SetHOMECmd(ref hcmd,false,ref idx);
                            if (k == 0) response = "reached at Home";
                            break;
                        ////////////////////
                        case "ptp":                          
                            x = (float)Convert.ToDecimal(lst[1]);
                            y = (float)Convert.ToDecimal(lst[2]);
                            z = (float)Convert.ToDecimal(lst[3]);

                            PTPCmd pcmd = new PTPCmd();
                            pcmd.x = x;
                            pcmd.y = y;
                            pcmd.z = z;
                            idx = 0;
                            k = DobotDll.SetPTPCmd(ref pcmd, false, ref idx);
                            if (k == 0) response = "PTP command executed";

                            break;
                        ///////////////////
                        case "j1+":
                            idx = 0;
                            JogCmd jcmd = new JogCmd();
                            jcmd.isJoint = 1;
                            jcmd.cmd = 1;
                            k = DobotDll.SetJOGCmd(ref jcmd,false,ref idx);
                            if (k == 0) response = "Joint j1+ done";
                            break;
                        ///////////////////
                        case "j1-":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 2;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j1- done";
                            break;
                        ///////////////////
                        case "j2+":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 3;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j2+ done";
                            break;
                        ///////////////////
                        case "j2-":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 4;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j2- done";
                            break;
                        ///////////////////
                        case "j3+":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 5;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j3+ done";
                            break;
                        ///////////////////
                        case "j3-":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 6;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j3- done";
                            break;
                        ///////////////////
                        case "j4+":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 7;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j4+ done";
                            break;
                        ///////////////////
                        case "j4-":
                            idx = 0;
                            jcmd.isJoint = 1;
                            jcmd.cmd = 8;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "Joint j4- done";
                            break;
                        ///////////////////
                        case "x+":
                            idx = 0;
                            jcmd = new JogCmd();
                            jcmd.isJoint = 0;
                            jcmd.cmd = 1;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "x+ done";
                            break;
                        ///////////////////
                        case "x-":
                            idx = 0;
                            jcmd.isJoint = 0;
                            jcmd.cmd = 2;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "x- done";
                            break;
                        ///////////////////
                        case "y+":
                            idx = 0;
                            jcmd.isJoint = 0;
                            jcmd.cmd = 3;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "y+ done";
                            break;
                        ///////////////////
                        case "y-":
                            idx = 0;
                            jcmd.isJoint = 0;
                            jcmd.cmd = 4;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "y- done";
                            break;
                        ///////////////////
                        case "z+":
                            idx = 0;
                            jcmd.isJoint = 0;
                            jcmd.cmd = 5;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "z+ done";
                            break;
                        ///////////////////
                        case "z-":
                            idx = 0;
                            jcmd.isJoint = 0;
                            jcmd.cmd = 6;
                            k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            if (k == 0) response = "z- done";
                            break;
                        ///////////////////
                        case "set_arc_param":
                            float  vel_xyz =(float)Convert.ToDecimal(lst[1]);
                            float  vel_r =  (float)Convert.ToDecimal(lst[2]);
                            float accl_xyz =(float)Convert.ToDecimal(lst[3]);
                            float accl_r =  (float)Convert.ToDecimal(lst[4]);

                            ARCParams arp = new ARCParams();
                            arp.xyzVelocity = vel_xyz;
                            arp.rVelocity = vel_r;
                            arp.xyzAcceleration = accl_xyz;
                            arp.rAcceleration = accl_r;
                            idx = 0;
 
                            k = DobotDll.SetARCParams(ref arp, false,ref idx);
                            if (k == 0) response = "ARC Param set OK";
                            break;
                        //////////////////////
                        case "get_arc_param":
                            arp = new ARCParams();
                            k = DobotDll.GetARCParams(ref arp);

                            string ap = "ARC PARAM=";
                            ap += "xyz vel=" + arp.xyzVelocity.ToString();
                            ap += "r vel=" + arp.xyzVelocity.ToString();
                            ap += "xyz accln.=" + arp.xyzAcceleration.ToString();
                            ap += "r accln.=" + arp.rAcceleration.ToString();
                            if (k == 0) response = ap;
                            break;
                        //////////////////////
                        case "go_arc":
                            float cirX = (float)Convert.ToDecimal(lst[1]);
                            float cirY = (float)Convert.ToDecimal(lst[2]);
                            float cirZ = (float)Convert.ToDecimal(lst[3]);
                            float cirR = (float)Convert.ToDecimal(lst[4]);

                            float toX = (float)Convert.ToDecimal(lst[5]);
                            float toY = (float)Convert.ToDecimal(lst[6]);
                            float toZ = (float)Convert.ToDecimal(lst[7]);
                            float toR = (float)Convert.ToDecimal(lst[8]);

                            ARCCmd acmd = new ARCCmd();
                            acmd.cirPoint_x = cirX;
                            acmd.cirPoint_y = cirY;
                            acmd.cirPoint_z = cirZ;
                            acmd.cirPoint_r = cirR;

                            acmd.toPoint_x = toX;
                            acmd.toPoint_y = toY;
                            acmd.toPoint_z = toZ;
                            acmd.toPoint_r = toR;

                            idx = 0;
                            k = DobotDll.SetARCCmd(ref acmd,false,ref idx);

                            if (k == 0) response = "ARC command Send";
                            break;
                        //////////////////////
                        case "set_ptp_jump":
                            PTPJumpParams pj = new PTPJumpParams();
                            pj.jumpHeight= (float)Convert.ToDecimal(lst[1]);
                            pj.zLimit= (float)Convert.ToDecimal(lst[2]);
                            idx = 0;
                            k = DobotDll.SetPTPJumpParams(ref pj,false,ref idx);
 
                            if (k == 0) response = "PTP Jump Param Set OK";
                            break;
                        //////////////////////
                        case "get_ptp_jump":
                            pj = new PTPJumpParams();                         
                            k = DobotDll.GetPTPJumpParams(ref pj);
                            string jp = "PTP JUMP PARAM=";
                            jp += "Jump Height=" + pj.jumpHeight.ToString();
                            jp += ",Zlimit=" + pj.zLimit.ToString();             
                            if (k == 0) response = "PTP Jump Param Set OK";
                            break;
                        //////////////////////
                        default:
                            response = "Error:Command Not Found!!";
                            break;
                    }
                    command = "";
                }
            }
        }

        public bool reach_target(Pose p)
        {
            bool x, y, z;

            Pose target = new Pose();
            DobotDll.GetPose(ref target);

            x=utility.value_Not_In_Tolerance(p.x,target.x,1.0);
            y = utility.value_Not_In_Tolerance(p.y,target.y,1.0);
            z = utility.value_Not_In_Tolerance(p.z, target.z, 1.0);

            if((x ==false) && (y ==false) && (z ==false))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool connected(string port)
        {
            StringBuilder fwType = new StringBuilder(60);
            StringBuilder version = new StringBuilder(60);
            int ret = DobotDll.ConnectDobot(port, 115200, fwType, version);
           
            // start connect
            if (ret != (int)DobotConnect.DobotConnect_NoError)
            {
                // Msg("Connect error", MsgInfoType.Error);
                return false; 
            }
            // Msg("Connect success", MsgInfoType.Info);

            //   isConnectted = true;
            DobotDll.SetCmdTimeout(3000);

            // Must set when sensor is not exist
            //DobotDll.ResetPose(true, 45, 45);

            // Get name
          //  string deviceName = "Dobot Magician";
          //  DobotDll.SetDeviceName(deviceName);

          //  StringBuilder deviceSN = new StringBuilder(64);
         //   DobotDll.GetDeviceName(deviceSN, 64);

            SetParam();
            AlarmTest();
            isConnectted = true;
            return true;

        }
     
        public void Disconnect()
        {
            DobotDll.DisconnectDobot();
            isConnectted = false;
        }
        
        private void SetParam()
        {
            UInt64 cmdIndex = 0;
            JOGJointParams jsParam;
            jsParam.velocity = new float[] { 200, 200, 200, 200 };
            jsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetJOGJointParams(ref jsParam, false, ref cmdIndex);

            JOGCommonParams jdParam;
            jdParam.velocityRatio = 100;
            jdParam.accelerationRatio = 100;
            DobotDll.SetJOGCommonParams(ref jdParam, false, ref cmdIndex);

            PTPJointParams pbsParam;
            pbsParam.velocity = new float[] { 200, 200, 200, 200 };
            pbsParam.acceleration = new float[] { 200, 200, 200, 200 };
            DobotDll.SetPTPJointParams(ref pbsParam, false, ref cmdIndex);

            PTPCoordinateParams cpbsParam;
            cpbsParam.xyzVelocity = 100;
            cpbsParam.xyzAcceleration = 100;
            cpbsParam.rVelocity = 100;
            cpbsParam.rAcceleration = 100;
            DobotDll.SetPTPCoordinateParams(ref cpbsParam, false, ref cmdIndex);

            PTPJumpParams pjp;
            pjp.jumpHeight = 20;
            pjp.zLimit = 100;
            DobotDll.SetPTPJumpParams(ref pjp, false, ref cmdIndex);

            PTPCommonParams pbdParam;
            pbdParam.velocityRatio = 30;
            pbdParam.accelerationRatio = 30;
            DobotDll.SetPTPCommonParams(ref pbdParam, false, ref cmdIndex);
        }

        private void AlarmTest()
        {
            int ret;
            byte[] alarmsState = new byte[32];
            UInt32 len = 32;
            ret = DobotDll.GetAlarmsState(alarmsState, ref len, alarmsState.Length);
            for (int i = 0; i < alarmsState.Length; i++)
            {
                byte alarm = alarmsState[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((alarm & 0x01 << j) > 0)
                    {
                        int alarmIndex = i * 8 + j;
                        switch (alarmIndex)
                        {
                            case 0x00:
                                { // reset
                                    //Get Alarm status: reset
                                    break;
                                }
                            /* other status*/
                            default:
                                break;
                        }
                    }
                }
            }
            //DobotDll.ClearAllAlarmsState();
        }

        public void Get_Param(DataGridView dg)
        {
            Pose p = new Pose();
            DobotDll.GetPose(ref p);
            dg[1, 0].Value = p.jointAngle[0].ToString();
            dg[1, 1].Value = p.jointAngle[1].ToString();
            dg[1, 2].Value = p.jointAngle[2].ToString();
            dg[1, 3].Value = p.jointAngle[3].ToString();

            dg[1, 4].Value = p.x.ToString();
            dg[1, 5].Value = p.y.ToString();
            dg[1, 6].Value = p.z.ToString();
            dg[1, 7].Value = p.rHead.ToString(); 
        }

        private void EIOTest()
        {
            UInt64 cmdIndex = 0;

            //EIO
            IOMultiplexing iom;
            iom.address = 2;//io index
            iom.multiplex = (byte)IOFunction.IOFunctionDO; // ioType
            DobotDll.SetIOMultiplexing(ref iom, false, ref cmdIndex);

            IODO iod;
            iod.address = 2;
            iod.level = 1; // set io index 2 to open
            DobotDll.SetIODO(ref iod, false, ref cmdIndex);
        }

        private void ARCTest()
        {
            ptp((byte)1, 67.99f, 216.4f, -27.99f, 0);
            arc(154.92f, 182.41f, -62.89f, 0f, 216.07f, 85.54f, -8.34f, 0f);
        }

        public UInt64 ptp(byte style, float x, float y, float z, float r)
        {
            PTPCmd pdbCmd;
            UInt64 cmdIndex = 0;

            pdbCmd.ptpMode = style;
            pdbCmd.x = x;
            pdbCmd.y = y;
            pdbCmd.z = z;
            pdbCmd.rHead = r;
            while (true)
            {
                int ret = DobotDll.SetPTPCmd(ref pdbCmd, true, ref cmdIndex);

                if (ret == 0)
                    break;
            }

            return cmdIndex;
        }

        private UInt64 arc(float x, float y, float z, float r, float x1, float y1, float z1, float r1)
        {
            UInt64 cmdIndex = 0;

            ARCCmd arcCmd;
            arcCmd.cirPoint_x = x;
            arcCmd.cirPoint_y = y;
            arcCmd.cirPoint_z = z;
            arcCmd.cirPoint_r = r;

            arcCmd.toPoint_x = x1;
            arcCmd.toPoint_y = y1;
            arcCmd.toPoint_z = z1;
            arcCmd.toPoint_r = r1;
            while (true)
            {
                int ret = DobotDll.SetARCCmd(ref arcCmd, true, ref cmdIndex);
                if (ret == 0)
                    break;
            }

            return cmdIndex;
        }

        public UInt64 cp(byte mod, float x, float y, float z, float velocity)
        {
            CPCmd pdbCmd;
            UInt64 cmdIndex = 0;

            pdbCmd.cpMode = mod;
            pdbCmd.x = x;
            pdbCmd.y = y;
            pdbCmd.z = z;
            pdbCmd.velocity = velocity;
            while (true)
            {
                int ret = DobotDll.SetCPCmd(ref pdbCmd, true, ref cmdIndex);
                if (ret == 0)
                    break;
            }

            return cmdIndex;
        }

        public void MovX(byte dc)
        {
            ulong cmdIndex = 0;
            currentCmd.isJoint = 0;// isJoint;
            currentCmd.cmd = dc;            // (byte)JogCmdType.JogAPPressed; //: (byte)JogCmdType.JogIdle;
            DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);


           // DobotDll.GetPose()
        }

       





        //private void StartGetPose()
        //{
        //    posTimer.Elapsed += new System.Timers.ElapsedEventHandler(PosTimer_Tick);
        //    posTimer.Interval = 600;
        //    posTimer.Start();
        //}

        //private void PosTimer_Tick(object sender, System.Timers.ElapsedEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    DobotDll.GetPose(ref pose);

        //    this.Dispatcher.BeginInvoke((Action)delegate ()
        //    {
        //        tbJoint1Angle.Text = pose.jointAngle[0].ToString();
        //        tbJoint2Angle.Text = pose.jointAngle[1].ToString();
        //        tbJoint3Angle.Text = pose.jointAngle[2].ToString();
        //        tbJoint4Angle.Text = pose.jointAngle[3].ToString();

        //        if (sync.IsChecked == true)
        //        {
        //            X.Text = pose.x.ToString();
        //            Y.Text = pose.y.ToString();
        //            Z.Text = pose.z.ToString();
        //            rHead.Text = pose.rHead.ToString();
        //            pauseTime.Text = "0";
        //        }
        //    });
        //}



        //// event handle
        //private void ProcessEvt(object sender, EventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    Button obj = (Button)sender;
        //    String con = obj.Content.ToString();
        //    UInt64 cmdIndex = 0;

        //    float x, y, z, r, gripper, pTime;

        //    if (!float.TryParse(X.Text, out x) || !float.TryParse(Y.Text, out y) || !float.TryParse(Z.Text, out z) || !float.TryParse(rHead.Text, out r)
        //        || !float.TryParse(isGripper.Text, out gripper) || !float.TryParse(pauseTime.Text, out pTime))
        //    {
        //        Msg("Please input float formate", MsgInfoType.Error);
        //        return;
        //    }
        //    Msg("", MsgInfoType.Info);

        //    switch (con)
        //    {
        //        case "SendPlaybackCmd":
        //            {
        //                obj.IsEnabled = false;
        //                cmdIndex = ptp((byte)modeStyle.SelectedIndex, x, y, z, r);
        //                while (true)
        //                {
        //                    UInt64 retIndex = 0;
        //                    int ind = DobotDll.GetQueuedCmdCurrentIndex(ref retIndex);
        //                    if (ind == 0 && cmdIndex <= retIndex)
        //                    {
        //                        obj.IsEnabled = true;
        //                        break;
        //                    }
        //                }

        //                float waitTime = 0;
        //                if (float.TryParse(pauseTime.Text, out waitTime) && waitTime > 0)
        //                {
        //                    WAITCmd waitcmd;
        //                    waitcmd.timeout = (uint)waitTime;
        //                    DobotDll.SetWAITCmd(ref waitcmd, false, ref cmdIndex);
        //                }
        //            }
        //            break;
        //        case "SendCPCmd":
        //            {
        //                cmdIndex = cp((byte)ContinuousPathMode.CPAbsoluteMode, x, y, z, 100);
        //                while (true)
        //                {
        //                    UInt64 retIndex = 0;
        //                    int ind = DobotDll.GetQueuedCmdCurrentIndex(ref retIndex);
        //                    if (ind == 0 && cmdIndex <= retIndex)
        //                    {
        //                        obj.IsEnabled = true;
        //                        break;
        //                    }
        //                }
        //            }
        //            break;
        //        default:
        //            break;
        //    }
        //}

        // control event handle



        //private void OnEvent(object sender, MouseButtonEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    UInt64 cmdIndex = 0;
        //    Button obj = (Button)sender;
        //    String con = obj.Content.ToString();
        //    switch (con)
        //    {
        //        case "X+":
        //        case "Joint1+":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogAPPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "X-":
        //        case "Joint1-":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogANPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "Y+":
        //        case "Joint2+":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogBPPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "Y-":
        //        case "Joint2-":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogBNPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "Z+":
        //        case "Joint3+":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogCPPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "Z-":
        //        case "Joint3-":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogCNPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "R+":
        //        case "Joint4+":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogDPPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "R-":
        //        case "Joint4-":
        //            {
        //                currentCmd.isJoint = isJoint;
        //                currentCmd.cmd = e.ButtonState == MouseButtonState.Pressed ? (byte)JogCmdType.JogDNPressed : (byte)JogCmdType.JogIdle;
        //                DobotDll.SetJOGCmd(ref currentCmd, false, ref cmdIndex);
        //            }
        //            break;
        //        case "Gripper+":
        //            {

        //            }
        //            break;
        //        case "Gripper-":
        //            {

        //            }
        //            break;
        //        default:
        //            break;
        //    }
        //}

        //private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    ComboBox obj = (ComboBox)sender;
        //    String tag = obj.Tag.ToString();
        //    if (tag == "mode")
        //    {
        //        bool isJ = ((ComboBoxItem)obj.SelectedItem).Content.ToString() == "Axis";
        //        isJoint = isJ ? (byte)1 : (byte)0;
        //        if (isJ)
        //        {
        //            XI.Content = "Joint1+";
        //            YI.Content = "Joint2+";
        //            ZI.Content = "Joint3+";
        //            RI.Content = "Joint4+";

        //            XN.Content = "Joint1-";
        //            YN.Content = "Joint2-";
        //            ZN.Content = "Joint3-";
        //            RN.Content = "Joint4-";
        //        }
        //        else
        //        {
        //            XI.Content = "X+";
        //            YI.Content = "Y+";
        //            ZI.Content = "Z+";
        //            RI.Content = "R+";

        //            XN.Content = "X-";
        //            YN.Content = "Y-";
        //            ZN.Content = "Z-";
        //            RN.Content = "R-";
        //        }
        //    }
        //    else if (tag == "headType")
        //    {
        //        string str = ((ComboBoxItem)obj.SelectedItem).Content.ToString();
        //        if (str == "SuctionCup")
        //        {
        //            cbGrab.IsEnabled = false;
        //            cbLaser.IsEnabled = false;
        //            cbSuctionCup.IsEnabled = true;
        //            EndTypeParams endType;
        //            endType.xBias = 59.7f;
        //            endType.yBias = 0;
        //            endType.zBias = 0;
        //            DobotDll.SetEndEffectorParams(ref endType);
        //        }
        //        else if (str == "Gripper")
        //        {
        //            cbGrab.IsEnabled = true;
        //            cbLaser.IsEnabled = false;
        //            cbSuctionCup.IsEnabled = false;
        //            EndTypeParams endType;
        //            endType.xBias = 59.7f;
        //            endType.yBias = 0;
        //            endType.zBias = 0;
        //            DobotDll.SetEndEffectorParams(ref endType);
        //        }
        //        else if (str == "Laser")
        //        {
        //            cbGrab.IsEnabled = false;
        //            cbLaser.IsEnabled = true;
        //            cbSuctionCup.IsEnabled = false;
        //            EndTypeParams endType;
        //            endType.xBias = 70f;
        //            endType.yBias = 0;
        //            endType.zBias = 0;
        //            DobotDll.SetEndEffectorParams(ref endType);
        //        }

        //    }
        //}

        //private void Window_Closed(object sender, EventArgs e)
        //{
        //    DobotDll.DisconnectDobot();
        //}

        //private void Msg(string str, MsgInfoType infoType)
        //{
        //    lbTip.Content = str;
        //    switch (infoType)
        //    {
        //        case MsgInfoType.Error:
        //            lbTip.Foreground = new SolidColorBrush(Colors.Red);
        //            break;
        //        case MsgInfoType.Info:
        //            lbTip.Foreground = new SolidColorBrush(Colors.Black);
        //            break;
        //        default:
        //            break;
        //    }
        //}

        //private void CheckBox_Checked(object sender, RoutedEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    CheckBox obj = (CheckBox)sender;
        //    String con = obj.Content.ToString();
        //    UInt64 cmdIndex = 0;
        //    if (con == "Grab") // grab
        //    {
        //        DobotDll.SetEndEffectorGripper(true, true, false, ref cmdIndex);
        //    }
        //    else if (con == "Laser") // Shutting
        //    {
        //        DobotDll.SetEndEffectorLaser(true, true, false, ref cmdIndex);
        //    }
        //    else if (con == "SuctionCup")
        //    {
        //        DobotDll.SetEndEffectorSuctionCup(true, true, false, ref cmdIndex);
        //    }
        //}

        //private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    CheckBox obj = (CheckBox)sender;
        //    String con = obj.Content.ToString();
        //    UInt64 cmdIndex = 0;
        //    if (con == "Grab") // cancel grab
        //    {
        //        DobotDll.SetEndEffectorGripper(true, false, false, ref cmdIndex);
        //    }
        //    else if (con == "Laser") // release laser
        //    {
        //        DobotDll.SetEndEffectorLaser(false, false, false, ref cmdIndex);
        //    }
        //    else if (con == "SuctionCup")
        //    {
        //        DobotDll.SetEndEffectorSuctionCup(false, false, false, ref cmdIndex);
        //    }
        //}

        //private void blurSlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        //{
        //    if (!isConnectted)
        //        return;

        //    UInt64 cmdIndex = 0;
        //    Slider obj = (Slider)sender;
        //    if (obj.Name == "sld")
        //    {
        //        JOGCommonParams jdParam;
        //        jdParam.velocityRatio = (float)sld.Value;
        //        jdParam.accelerationRatio = 100;
        //        DobotDll.SetJOGCommonParams(ref jdParam, false, ref cmdIndex);
        //    }
        //    else if (obj.Name == "sld1" || obj.Name == "sldAcc") // playback
        //    {
        //        PTPCommonParams pbdParam;
        //        pbdParam.velocityRatio = (float)sld1.Value;
        //        pbdParam.accelerationRatio = (float)sldAcc.Value;
        //        DobotDll.SetPTPCommonParams(ref pbdParam, false, ref cmdIndex);
        //    }
        //}
















    }// class
}// NS
