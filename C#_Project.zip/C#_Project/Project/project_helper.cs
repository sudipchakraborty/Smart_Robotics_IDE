﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Tools;

namespace Project
{
    public static class project_helper
    {
       static json_handler mem = new json_handler("settings.json");

        public static void Load_Settings()
        {
           prj_global.Port = mem.Get("Port");
           prj_global.Baud_Rate = mem.Get("Baud_Rate");
           prj_global.File_Path = mem.Get("File_Path");
           prj_global.Selected_Robot=mem.Get("Selected_Robot");
        }
        
        public static void Save_Settings()
        {
            mem.put("Port", prj_global.Port);
            mem.put("Baud_Rate", prj_global.Baud_Rate);
            mem.put("File_Path", prj_global.File_Path);
            mem.put("Selected_Robot", prj_global.Selected_Robot);
        }
     





















    }
}
